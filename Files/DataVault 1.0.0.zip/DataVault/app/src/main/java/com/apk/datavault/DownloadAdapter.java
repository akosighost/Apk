package com.apk.datavault;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DownloadAdapter extends ArrayAdapter<String> {

    private Context context;
    private ArrayList<String> fileList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(String fileName);
    }

    public DownloadAdapter(Context context, ArrayList<String> fileList, OnItemClickListener listener) {
        super(context, R.layout.home_list, fileList);
        this.context = context;
        this.fileList = fileList;
        this.listener = listener;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(R.layout.home_list, parent, false);
        }

        final String fileName = fileList.get(position);

        final TextView textview1 = listItemView.findViewById(R.id.textview1);
        final TextView textview2 = listItemView.findViewById(R.id.textview2);
        final TextView textview3 = listItemView.findViewById(R.id.textview3);
        final TextView textview4 = listItemView.findViewById(R.id.textview4);
        final TextView type1 = listItemView.findViewById(R.id.type1);
        final TextView type2 = listItemView.findViewById(R.id.type2);
        final TextView type3 = listItemView.findViewById(R.id.type3);
        final TextView type4 = listItemView.findViewById(R.id.type4);
        final LinearLayout linear1 = listItemView.findViewById(R.id.linear1);
        final LinearLayout linear2 = listItemView.findViewById(R.id.linear2);
        final LinearLayout linear5 = listItemView.findViewById(R.id.linear5);
        final LinearLayout type_container = listItemView.findViewById(R.id.type_container);
        final LinearLayout type_holder1 = listItemView.findViewById(R.id.type_holder1);
        final LinearLayout type_holder2 = listItemView.findViewById(R.id.type_holder2);
        final LinearLayout type_holder3 = listItemView.findViewById(R.id.type_holder3);
        final LinearLayout type_holder4 = listItemView.findViewById(R.id.type_holder4);

        textview1.setText(String.valueOf((long)(position + 1)));
        textview2.setText(fileName.replace(".apk", ""));
        textview3.setVisibility(View.GONE);
        textview4.setVisibility(View.GONE);
        type_container.setVisibility(View.GONE);

        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getContext().getResources().getDisplayMetrics().density;
            SketchUi.setCornerRadius(d*300);
            SketchUi.setStroke(d*1,0xFF9E9E9E);
            type_holder1.setBackground(SketchUi);
        }
        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getContext().getResources().getDisplayMetrics().density;
            SketchUi.setCornerRadius(d*300);
            SketchUi.setStroke(d*1,0xFF2196F3);
            type_holder2.setBackground(SketchUi);
        }
        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getContext().getResources().getDisplayMetrics().density;
            SketchUi.setCornerRadius(d*300);
            SketchUi.setStroke(d*1,0xFFF44336);
            type_holder3.setBackground(SketchUi);
        }
        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getContext().getResources().getDisplayMetrics().density;
            SketchUi.setCornerRadius(d * 300);
            SketchUi.setStroke(d * 1, 0xFF228B22);
            type_holder4.setBackground(SketchUi);
        }

        listItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Trigger the onItemClick method in the listener
                if (listener != null) {
                    listener.onItemClick(fileName);
                }
            }
        });
        linear1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                install("/DataVault/files/".concat(fileName));
            }
        });
        return listItemView;
    }

    public void install(final String apk) {
        String PATH = Environment.getExternalStorageDirectory() + apk;
        java.io.File file = new java.io.File(PATH);
        if (file.exists()) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uriFromFile(context.getApplicationContext(), new java.io.File(PATH)), "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                context.getApplicationContext().startActivity(intent);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
                Log.e("TAG", "Error in opening the file!");
            }
        } else {
            Toast.makeText(context.getApplicationContext(),"installing",Toast.LENGTH_LONG).show();
        }
    }
    Uri uriFromFile(Context context, java.io.File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return androidx.core.content.FileProvider.getUriForFile(context,context.getApplicationContext().getPackageName() + ".provider", file);
        } else {
            return Uri.fromFile(file);
        }
    }
}