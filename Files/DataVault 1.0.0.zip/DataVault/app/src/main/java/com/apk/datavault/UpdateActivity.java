package com.apk.datavault;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.downloader.Progress;
import com.google.firebase.FirebaseApp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class UpdateActivity extends AppCompatActivity {

    private TextView value;
    private TextView percent;
    private TextView text;
    private ProgressBar progressBar;
    private ImageView image;
    private LinearLayout prog;
    private LinearLayout image_holder;

    private Handler handler;
    private int dotCount = 0;

    private double number = 0;
    private int downloadId;
    private RequestNetwork net;
    private RequestNetwork.RequestListener _net_request_listener;
    private Runnable dotAnimationRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        initialize(savedInstanceState);
        FirebaseApp.initializeApp(this);
        initialize();
    }

    private void initialize(Bundle savedInstanceState) {
        net = new RequestNetwork(this);
        value = findViewById(R.id.value);
        percent = findViewById(R.id.percent);
        text = findViewById(R.id.text);
        progressBar = findViewById(R.id.progress);
        image = findViewById(R.id.image);
        prog = findViewById(R.id.prog);
        image_holder = findViewById(R.id.image_holder);

        _net_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;

            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;

            }
        };
    }

    private void initialize() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.dark));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.dark));
        progressBar.getIndeterminateDrawable().setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
        handler = new Handler();
        startDotAnimation();

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (number == 1) {
                    number = 0;
                    PRDownloader.resume(downloadId);
                    image.setImageResource(R.drawable.pause);
                } else if (number == 0) {
                    number = 1;
                    PRDownloader.pause(downloadId);
                    image.setImageResource(R.drawable.resume);
                }
            }
        });

        PRDownloader.initialize(getApplicationContext());

        PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
                .setDatabaseEnabled(true)
                .build();
        PRDownloader.initialize(getApplicationContext(), config);

        downloadId = PRDownloader.download(getIntent().getStringExtra("link").replace("blob", "raw"), FileUtil.getExternalStorageDir().concat("/DataVault/files/"), getIntent().getStringExtra("name").concat(".apk"))
                .build()
                .setOnStartOrResumeListener(new OnStartOrResumeListener() {
                    @Override
                    public void onStartOrResume() {

                    }
                })
                .setOnPauseListener(new OnPauseListener() {
                    @Override
                    public void onPause() {
                        image.setImageResource(R.drawable.resume);
                    }
                })
                .setOnCancelListener(new OnCancelListener() {
                    @Override
                    public void onCancel() {
                        image.setImageResource(R.drawable.pause);
                    }
                })
                .setOnProgressListener(new OnProgressListener() {
                    @Override
                    public void onProgress(Progress progress) {
                        long progressPercent = progress.currentBytes * 100 / progress.totalBytes;
                        value.setText(Utils.getProgressDisplayLine(progress.currentBytes, progress.totalBytes));
                        progressBar.setProgress((int)progressPercent);
                        percent.setText(String.valueOf((long)progressPercent).concat(" %"));
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        double num = 100.0;
                        _Transition(image_holder, num);
                        image.setVisibility(View.GONE);
                        stopDotAnimation();
                        text.setText("Download Success");
                        install("/DataVault/files/".concat(getIntent().getStringExtra("name").concat(".apk")));
                    }

                    @Override
                    public void onError(Error error) {
                        Toast.makeText(UpdateActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void _Transition(final View _view, final double _duration) {
        LinearLayout ViewGroup = (LinearLayout) _view;
        android.transition.AutoTransition autoTransition = new android.transition.AutoTransition();
        autoTransition.setDuration((long)_duration);
        android.transition.TransitionManager.beginDelayedTransition(ViewGroup, autoTransition);
    }

    private void startDotAnimation() {
        dotAnimationRunnable = new Runnable() {
            @Override
            public void run() {
                dotCount = (dotCount + 1) % 4;
                updateText(dotCount);
                handler.postDelayed(this, 500); // Change the duration here to control the animation speed.
            }
        };
        handler.postDelayed(dotAnimationRunnable, 0);
    }


    private void stopDotAnimation() {
        if (dotAnimationRunnable != null) {
            handler.removeCallbacks(dotAnimationRunnable);
            dotAnimationRunnable = null;
        }
    }

    private void updateText(int dotCount) {
        StringBuilder dotsBuilder = new StringBuilder();
        for (int i = 0; i < dotCount; i++) {
            dotsBuilder.append(".");
        }
        text.setText("Downloading" + dotsBuilder);
    }

    public void install(final String apk) {
        String PATH = Environment.getExternalStorageDirectory() + apk;
        java.io.File file = new java.io.File(PATH);
        if (file.exists()) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uriFromFile(getApplicationContext(), new java.io.File(PATH)), "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                getApplicationContext().startActivity(intent);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
                Log.e("TAG", "Error in opening the file!");
            }
        } else {
            Toast.makeText(getApplicationContext(),"installing",Toast.LENGTH_LONG).show();
        }
    }
    Uri uriFromFile(Context context, java.io.File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return androidx.core.content.FileProvider.getUriForFile(context,context.getApplicationContext().getPackageName() + ".provider", file);
        } else {
            return Uri.fromFile(file);
        }
    }

    @Override
    public void onBackPressed() {
    }

    @Deprecated
    public void showMessage(String _s) {
        Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View _v) {
        int[] _location = new int[2];
        _v.getLocationInWindow(_location);
        return _location[0];
    }

    @Deprecated
    public int getLocationY(View _v) {
        int[] _location = new int[2];
        _v.getLocationInWindow(_location);
        return _location[1];
    }

    @Deprecated
    public int getRandom(int _min, int _max) {
        Random random = new Random();
        return random.nextInt(_max - _min + 1) + _min;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
        ArrayList<Double> _result = new ArrayList<Double>();
        SparseBooleanArray _arr = _list.getCheckedItemPositions();
        for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
            if (_arr.valueAt(_iIdx))
                _result.add((double) _arr.keyAt(_iIdx));
        }
        return _result;
    }

    @Deprecated
    public float getDip(int _input) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}