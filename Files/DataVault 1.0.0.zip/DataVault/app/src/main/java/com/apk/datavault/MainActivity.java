package com.apk.datavault;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private Timer timerTask = new Timer();
    private TimerTask timer;
    private Intent i = new Intent();

    private ProgressBar progressBar;
    private TextView loading;

    private Handler handler;
    private int dotCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize(savedInstanceState);
        FirebaseApp.initializeApp(this);
        initialize();
    }

    @Override
    protected void onStart() {
        super.onStart();
        timer = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (Build.VERSION.SDK_INT >= 23) {
                            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED || ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                                i.setClass(getApplicationContext(), PermissionActivity.class);
                                startActivity(i);
                            } else {
                                if (DataUtil.isConnected(getApplicationContext())) {
                                    i.setClass(getApplicationContext(), HomeActivity.class);
                                    startActivity(i);
                                } else {
                                    i.setClass(getApplicationContext(), DownloadActivity.class);
                                    startActivity(i);
                                }
                            }
                        } else {
                            if (DataUtil.isConnected(getApplicationContext())) {
                                i.setClass(getApplicationContext(), HomeActivity.class);
                                startActivity(i);
                            } else {
                                i.setClass(getApplicationContext(), DownloadActivity.class);
                                startActivity(i);
                            }
                        }
                    }
                });
            }
        };
        timerTask.schedule(timer, (int) 3000);
    }

    private void initialize(Bundle savedInstanceState) {
        progressBar = findViewById(R.id.progressbar1);
        loading = findViewById(R.id.loading);
    }

    private void initialize() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.dark));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.dark));
        progressBar.getIndeterminateDrawable().setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);

        handler = new Handler();
        startDotAnimation();
    }

    private void startDotAnimation() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                dotCount = (dotCount + 1) % 4;
                updateText(dotCount);
                handler.postDelayed(this, 500); // Change the duration here to control the animation speed.
            }
        }, 0);
    }

    private void updateText(int dotCount) {
        StringBuilder dotsBuilder = new StringBuilder();
        for (int i = 0; i < dotCount; i++) {
            dotsBuilder.append(".");
        }
        loading.setText("Please wait" + dotsBuilder);
    }

    @Deprecated
    public void showMessage(String _s) {
        Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View _v) {
        int[] _location = new int[2];
        _v.getLocationInWindow(_location);
        return _location[0];
    }

    @Deprecated
    public int getLocationY(View _v) {
        int[] _location = new int[2];
        _v.getLocationInWindow(_location);
        return _location[1];
    }

    @Deprecated
    public int getRandom(int _min, int _max) {
        Random random = new Random();
        return random.nextInt(_max - _min + 1) + _min;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
        ArrayList<Double> _result = new ArrayList<Double>();
        SparseBooleanArray _arr = _list.getCheckedItemPositions();
        for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
            if (_arr.valueAt(_iIdx))
                _result.add((double) _arr.keyAt(_iIdx));
        }
        return _result;
    }

    @Deprecated
    public float getDip(int _input) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}