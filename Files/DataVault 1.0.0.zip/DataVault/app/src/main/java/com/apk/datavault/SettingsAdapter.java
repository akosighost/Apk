package com.apk.datavault;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import java.util.List;

public class SettingsAdapter extends ArrayAdapter<String> {

    private Context context;
    private List<String> item1;
    private List<String> item2;

    public SettingsAdapter(Context context, List<String> item1, List<String> item2) {
        super(context, 0, item1);
        this.context = context;
        this.item1 = item1;
        this.item2 = item2;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.settings_list, parent, false);
        }

        String currentItem = item1.get(position);
        String newItem = item2.get(position);

        TextView main = itemView.findViewById(R.id.textview1);
        TextView sub = itemView.findViewById(R.id.textview2);
        LinearLayout linear1 = itemView.findViewById(R.id.linear1);
        LinearLayout linear2 = itemView.findViewById(R.id.linear2);

        _GradientDrawable(linear1, 10, 0, 0, "#FF2A2B2F", "#000000", false, false, 0);

        main.setText(currentItem);
        sub.setText(newItem);
        if (!currentItem.equals("")) {
            main.setVisibility(View.VISIBLE);
            main.setText(currentItem);
        } else {
            main.setVisibility(View.GONE);
        }
        if (!newItem.equals("")) {
            sub.setVisibility(View.VISIBLE);
            sub.setText(newItem);
        } else {
            sub.setVisibility(View.GONE);
        }
        // You can customize the ImageView and other views here if needed

        return itemView;
    }
    public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
        if (_ripple) {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(Color.parseColor(_color));
            gd.setCornerRadius((int)_radius);
            gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
            _view.setElevation((int)_shadow);
            android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
            android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
            _view.setClickable(true);
            _view.setBackground(ripdrb);
        }
        else {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(Color.parseColor(_color));
            gd.setCornerRadius((int)_radius);
            gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
            _view.setBackground(gd);
            _view.setElevation((int)_shadow);
        }
        if (_clickAnim) {
            _view.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()){
                        case MotionEvent.ACTION_DOWN:{
                            ObjectAnimator scaleX = new ObjectAnimator();
                            scaleX.setTarget(_view);
                            scaleX.setPropertyName("scaleX");
                            scaleX.setFloatValues(0.9f);
                            scaleX.setDuration((int)_animDuration);
                            scaleX.start();

                            ObjectAnimator scaleY = new ObjectAnimator();
                            scaleY.setTarget(_view);
                            scaleY.setPropertyName("scaleY");
                            scaleY.setFloatValues(0.9f);
                            scaleY.setDuration((int)_animDuration);
                            scaleY.start();
                            break;
                        }
                        case MotionEvent.ACTION_UP:{

                            ObjectAnimator scaleX = new ObjectAnimator();
                            scaleX.setTarget(_view);
                            scaleX.setPropertyName("scaleX");
                            scaleX.setFloatValues((float)1);
                            scaleX.setDuration((int)_animDuration);
                            scaleX.start();

                            ObjectAnimator scaleY = new ObjectAnimator();
                            scaleY.setTarget(_view);
                            scaleY.setPropertyName("scaleY");
                            scaleY.setFloatValues((float)1);
                            scaleY.setDuration((int)_animDuration);
                            scaleY.start();

                            break;
                        }
                    }
                    return false;
                }
            });
        }
    }

}
