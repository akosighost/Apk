package com.apk.datavault;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.URLUtil;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import io.github.rupinderjeet.kprogresshud.KProgressHUD;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class HomeActivity extends AppCompatActivity {

    private SwipeRefreshLayout swipeRefreshLayout;
    private ListView listView;
    private EditText search;
    private LinearLayout close_holder;
    private LinearLayout search_holder;
    private ImageView close;
    private ImageView settings;
    private LinearLayout linear1;
    private HorizontalScrollView scroll1;
    private LinearLayout slot1;
    private LinearLayout slot2;
    private LinearLayout slot3;
    private TextView textview_slot1;
    private TextView textview_slot2;
    private TextView textview_slot3;
    private RequestNetwork internet;
    private RequestNetwork.RequestListener _internet_request_listener;
    private RequestNetwork update;
    private RequestNetwork.RequestListener _update_request_listener;
    private AlertDialog cv;
    private AlertDialog updateDialog;
    private SharedPreferences save;
    private Intent intent = new Intent();
    private OnCompleteListener Fcm_onCompleteListener;
    private ArrayList<HashMap<String, Object>> datakey = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> dataupdate = new ArrayList<>();
    private String string_search = "";
    private String value = "";
    private double number = 0;
    private double length = 0;
    private double size = 0;
    private double sumCount = 0;
    private String file = "";
    private String filename = "";
    private String result = "";
    private String newName = "";
    private String data = "";
    private String path = "";
    private String path1 = "";
    private String data1 = "https://akosighost.github.io/Apk/";
    private String data2 = "https://akosighost.github.io/Apk-Games/";
    private String UpdateData = "https://akosighost.github.io/ApkHub-Update/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initialize(savedInstanceState);
        FirebaseApp.initializeApp(this);
        initialize();

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED || ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[] {android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
        } else {
            initialize();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            initialize();
        }
    }

    private void initialize(Bundle savedInstanceState) {
        internet = new RequestNetwork(this);
        update = new RequestNetwork(this);
        save = getSharedPreferences("save", Activity.MODE_PRIVATE);
        swipeRefreshLayout = findViewById(R.id.swipe);
        search = findViewById(R.id.search);
        search_holder = findViewById(R.id.search_holder);
        close_holder = findViewById(R.id.close_holder);
        close = findViewById(R.id.close);
        settings = findViewById(R.id.settings);
        listView = findViewById(R.id.list_item);
        linear1 = findViewById(R.id.linear1);
        scroll1 = findViewById(R.id.scroll1);
        slot1 = findViewById(R.id.slot1);
        slot2 = findViewById(R.id.slot2);
        slot3 = findViewById(R.id.slot3);
        textview_slot1 = findViewById(R.id.textview_slot1);
        textview_slot2 = findViewById(R.id.textview_slot2);
        textview_slot3 = findViewById(R.id.textview_slot3);

        _internet_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;
                try {
                    swipeRefreshLayout.setRefreshing(false);
                    datakey = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
                    listView.setAdapter(new listAdapter(datakey));
                    ((BaseAdapter)listView.getAdapter()).notifyDataSetChanged();
                    string_search = new Gson().toJson(datakey);
                    DataUtil.sortListMap(datakey, "name", false, true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(HomeActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                    swipeRefreshLayout.setRefreshing(false);
                }
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;
            }
        };
        _update_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;
                swipeRefreshLayout.setRefreshing(false);
                try{
                    dataupdate = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
                    try {
                        android.content.pm.PackageManager pm = getApplicationContext().getPackageManager(); android.content.pm.PackageInfo pinfo = pm.getPackageInfo(getApplicationContext().getPackageName().toString(), 0); String your_version = pinfo.versionName;
                        if (!your_version.equals(dataupdate.get((int)0).get("version").toString())) {
                            updateDialog = new AlertDialog.Builder(HomeActivity.this).create();
                            LayoutInflater cvLI = getLayoutInflater();
                            View cvCV = (View) cvLI.inflate(R.layout.dialog_popup, null);
                            updateDialog.setView(cvCV);
                            updateDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            final TextView title = (TextView) cvCV.findViewById(R.id.textview1);
                            final TextView descriptions = (TextView) cvCV.findViewById(R.id.textview2);
                            final TextView size = (TextView) cvCV.findViewById(R.id.textview3);
                            final TextView button1 = (TextView) cvCV.findViewById(R.id.button1);
                            final TextView button2 = (TextView) cvCV.findViewById(R.id.button2);
                            if (dataupdate.get((int)0).containsKey("size")) {
                                if (!dataupdate.get((int)0).get("size").equals("")) {
                                    size.setVisibility(View.VISIBLE);
                                    size.setText(dataupdate.get((int)0).get("size").toString());
                                } else {
                                    size.setVisibility(View.GONE);
                                }
                            } else {
                                size.setVisibility(View.GONE);
                            }

                            if (dataupdate.get((int)0).containsKey("title")) {
                                title.setVisibility(View.VISIBLE);
                                title.setText(dataupdate.get((int)0).get("title").toString().trim());
                            } else {
                                title.setVisibility(View.GONE);
                            }
                            if (dataupdate.get((int)0).containsKey("description")) {
                                descriptions.setVisibility(View.VISIBLE);
                                descriptions.setText(dataupdate.get((int)0).get("description").toString().trim());
                            } else {
                                descriptions.setVisibility(View.GONE);
                            }
                            button2.setText("UPDATE NOW");
                            button1.setOnClickListener(view -> {
                                updateDialog.dismiss();
                            });
                            button2.setOnClickListener(view -> {
                                if (dataupdate.get((int)0).containsKey("link")) {
                                    if (!dataupdate.get((int)0).get("link").equals("")) {
                                        intent.setClass(getApplicationContext(), UpdateActivity.class);
                                        intent.putExtra("link", dataupdate.get((int)0).get("link").toString());
                                        if (dataupdate.get((int)0).containsKey("version")) {
                                            if (!dataupdate.get((int)0).get("version").equals("")) {
                                                intent.putExtra("version", dataupdate.get((int)0).get("version").toString());
                                            }
                                        }
                                        if (dataupdate.get((int)0).containsKey("size")) {
                                            if (!dataupdate.get((int)0).get("size").equals("")) {
                                                intent.putExtra("size", dataupdate.get((int)0).get("size").toString());
                                            }
                                        }
                                        if (dataupdate.get((int)0).containsKey("name")) {
                                            if (!dataupdate.get((int)0).get("name").equals("")) {
                                                intent.putExtra("name", dataupdate.get((int)0).get("name").toString());
                                            }
                                        }
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(HomeActivity.this, "Unable to update!", Toast.LENGTH_SHORT).show();
                                    }
                                }
                                else {
                                    Toast.makeText(HomeActivity.this, "Unable to update!", Toast.LENGTH_SHORT).show();
                                }
                            });
                            updateDialog.setCancelable(false);
                            updateDialog.show();
                        }
                    } catch (android.content.pm.PackageManager.NameNotFoundException e) { e.printStackTrace(); }
                }catch(Exception e){
                    Toast.makeText(HomeActivity.this, "can't resolve api host", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;
            }
        };
        close.setOnClickListener(view -> {
            search.setText("");
        });
        settings.setOnClickListener(view -> {
            intent.setClass(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
                final String _charSeq = _param1.toString();
                double num = 200.0;
                if (search.getText().toString().length() == 0) {
                    _Transition(search_holder, num);
                    _Transition(close_holder, num);
                    close_holder.setVisibility(View.GONE);
                    search.setCursorVisible(false);

                } else {
                    _Transition(search_holder, num);
                    _Transition(close_holder, num);
                    close_holder.setVisibility(View.VISIBLE);
                    search.setCursorVisible(true);
                }

                try {
                    datakey = new Gson().fromJson(string_search, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
                    length = datakey.size();
                    number = length - 1;
                    for (int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
                        value = datakey.get((int)number).get("name").toString();

                        if (!(_charSeq.length() > value.length()) && value.toLowerCase().contains(_charSeq.toLowerCase())) {

                        }
                        else {
                            datakey.remove((int)(number));
                            listView.setAdapter(new listAdapter(datakey));
                            ((BaseAdapter)listView.getAdapter()).notifyDataSetChanged();
                        }
                        number --;
                    }
                    listView.setAdapter(new listAdapter(datakey));
                    ((BaseAdapter)listView.getAdapter()).notifyDataSetChanged();
                }
                catch (Exception e) {

                }
            }

            @Override
            public void afterTextChanged(Editable _param1) {

            }

            @Override
            public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {

            }
        });
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onStart() {
        super.onStart();
        update.startRequestNetwork(RequestNetworkController.GET, UpdateData, "", _update_request_listener);
    }

    private void initialize() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.dark));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.dark));
        update.startRequestNetwork(RequestNetworkController.GET, UpdateData, "", _update_request_listener);
        scroll1.setHorizontalScrollBarEnabled(false);
        scroll1.setVerticalScrollBarEnabled(false);
        OverScrollDecoratorHelper.setUpOverScroll(scroll1);
        swipeRefreshLayout.setHorizontalScrollBarEnabled(false);
        swipeRefreshLayout.setHorizontalScrollBarEnabled(false);
        _OnCreate();
        dark(slot1);
        dark(slot2);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(true);
                update.startRequestNetwork(RequestNetworkController.GET, UpdateData, "", _update_request_listener);
            }
        });
        slot1.performClick();
        {
            GradientDrawable SketchUi = new GradientDrawable();
            int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            SketchUi.setColor(0xFF2A2B2F);
            SketchUi.setCornerRadius(d*5);
            SketchUi.setStroke(d*1,0xFF121F2B);
            search.setBackground(SketchUi);
        }
        listView.setHorizontalScrollBarEnabled(false);
        listView.setVerticalScrollBarEnabled(false);
        listView.setDivider(null);
        listView.setDividerHeight(0);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                internet.startRequestNetwork(RequestNetworkController.GET, data, "", _internet_request_listener);
                internet.startRequestNetwork(RequestNetworkController.GET, UpdateData, "", _internet_request_listener);
            }
        });
    }

    public class listAdapter extends BaseAdapter{

        ArrayList<HashMap<String, Object>> data;

        public listAdapter(ArrayList<HashMap<String, Object>> _arr) {
            data = _arr;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public HashMap<String, Object> getItem(int _index) {
            return data.get(_index);
        }

        @Override
        public long getItemId(int _index) {
            return _index;
        }

        @RequiresApi(api = Build.VERSION_CODES.R)
        @Override
        public View getView(final int position, View v, ViewGroup _container) {
            LayoutInflater _inflater = getLayoutInflater();
            View _view = v;
            if (_view == null) {
                _view = _inflater.inflate(R.layout.home_list, null);
            }

            final LinearLayout linear1 = _view.findViewById(R.id.linear1);
            final LinearLayout linear2 = _view.findViewById(R.id.linear2);
            final TextView textview1 = _view.findViewById(R.id.textview1);
            final TextView textview2 = _view.findViewById(R.id.textview2);
            final TextView textview3 = _view.findViewById(R.id.textview3);
            final TextView textview4 = _view.findViewById(R.id.textview4);
            final TextView type1 = _view.findViewById(R.id.type1);
            final TextView type2 = _view.findViewById(R.id.type2);
            final TextView type3 = _view.findViewById(R.id.type3);
            final TextView type4 = _view.findViewById(R.id.type4);
            final LinearLayout type_holder1 = _view.findViewById(R.id.type_holder1);
            final LinearLayout type_holder2 = _view.findViewById(R.id.type_holder2);
            final LinearLayout type_holder3 = _view.findViewById(R.id.type_holder3);
            final LinearLayout type_holder4 = _view.findViewById(R.id.type_holder4);
            final ImageView img1 = _view.findViewById(R.id.img1);
            final ImageView img2 = _view.findViewById(R.id.img2);
            final ImageView img3 = _view.findViewById(R.id.img3);
            final ImageView img4 = _view.findViewById(R.id.img4);
            textview3.setVisibility(View.GONE);
            textview4.setVisibility(View.GONE);
//            try {
//                if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/DataVault/files/").concat(data.get((int)position).get("name").toString().concat(data.get((int)position).get(" ").toString().concat(data.get((int)position).get("version").toString().concat(".apk")))))) {
//                    textview4.setVisibility(View.VISIBLE);
//                    textview4.setText("meron na");
//                } else {
//                    textview4.setVisibility(View.GONE);
//                }
//            } catch (Exception e) {
//                Toast.makeText(HomeActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
//            }
            textview4.setVisibility(View.GONE);
            Animation animation;
            animation = new AnimationUtils().loadAnimation(getApplicationContext(), android.R.anim.fade_in);
            animation.setDuration(700);
            linear1.startAnimation(animation);
            animation = null;
            _GradientDrawable(linear1, 0, 0, 0, "#FF202226", "#000000", false, false, 0);
            _GradientDrawable(linear2, 0, 2, 20, "#FF202226", "#FF2A2B2F", false, false, 0);
            {
                android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
                int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                SketchUi.setCornerRadius(d*300);
                SketchUi.setStroke(d*1,0xFF9E9E9E);
                type_holder1.setBackground(SketchUi);
            }
            {
                android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
                int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                SketchUi.setCornerRadius(d*300);
                SketchUi.setStroke(d*1,0xFF2196F3);
                type_holder2.setBackground(SketchUi);
            }
            {
                android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
                int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                SketchUi.setCornerRadius(d*300);
                SketchUi.setStroke(d*1,0xFFF44336);
                type_holder3.setBackground(SketchUi);
            }
            {
                android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
                int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                SketchUi.setCornerRadius(d*300);
                SketchUi.setStroke(d*1,0xFF228B22);
                type_holder4.setBackground(SketchUi);
            }
            textview1.setText(String.valueOf((long)(position + 1)));
            if (data.get((int)position).containsKey("name")) {
                if (!data.get((int)position).get("name").equals("")) {
                    linear1.setVisibility(View.VISIBLE);
                    textview2.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                    textview2.setText(data.get((int)position).get("name").toString().trim());
                    textview2.setSelected(true);
                    textview2.setSingleLine(true);
                } else {
                    linear1.setVisibility(View.GONE);
                }

            }
            if (data.get((int)position).containsKey("version")) {
                if (!data.get((int)position).get("version").equals("")) {
                    textview3.setVisibility(View.VISIBLE);
                    textview3.setText("Version : ".concat(data.get((int)position).get("version").toString()).trim());
                } else {
                    textview3.setVisibility(View.GONE);
                }
            } else {
                textview3.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("link")) {
                if (data.get((int)position).get("link").equals("")) {
                    textview4.setText("Unable to download.");
                } else {
                    textview4.setVisibility(View.GONE);
                }
            } else {
                textview4.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("type1")) {
                if (data.get((int)position).get("type1").equals("")) {
                    type_holder1.setVisibility(View.GONE);
                } else {
                    type_holder1.setVisibility(View.VISIBLE);
                    type1.setText(data.get((int)position).get("type1").toString().trim());
                }
            } else {
                type_holder1.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("type2")) {
                if (data.get((int)position).get("type2").equals("")) {
                    type_holder2.setVisibility(View.GONE);
                } else {
                    type_holder2.setVisibility(View.VISIBLE);
                    type2.setText(data.get((int)position).get("type2").toString().trim());
                }
            } else {
                type_holder2.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("type3")) {
                if (data.get((int)position).get("type3").equals("")) {
                    type_holder3.setVisibility(View.GONE);
                } else {
                    type_holder3.setVisibility(View.VISIBLE);
                    type3.setText(data.get((int)position).get("type3").toString().trim());
                }
            } else {
                type_holder3.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("type4")) {
                if (data.get((int)position).get("type4").equals("")) {
                    type_holder4.setVisibility(View.GONE);
                } else {
                    type_holder4.setVisibility(View.VISIBLE);
                    type4.setText(data.get((int)position).get("type4").toString().trim());
                }
            } else {
                type_holder4.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("img1")) {
                if (data.get((int)position).get("img1").equals("")) {
                    img1.setVisibility(View.GONE);
                } else {
                    img1.setVisibility(View.VISIBLE);
//                    Picasso.get().load(data.get((int)position).get("img1").toString()).into(img1);
                    Glide.with(getApplicationContext()).load(Uri.parse(data.get((int)position).get("img1").toString().replace("blob", "raw"))).into(img1);
                }
            } else {
                img1.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("img2")) {
                if (data.get((int)position).get("img2").equals("")) {
                    img2.setVisibility(View.GONE);
                } else {
                    img2.setVisibility(View.VISIBLE);
                    Glide.with(getApplicationContext()).load(Uri.parse(data.get((int)position).get("img2").toString().replace("blob", "raw"))).into(img2);
                }
            } else {
                img2.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("img3")) {
                if (data.get((int)position).get("img3").equals("")) {
                    img3.setVisibility(View.GONE);
                } else {
                    img3.setVisibility(View.VISIBLE);
                    Glide.with(getApplicationContext()).load(Uri.parse(data.get((int)position).get("img3").toString().replace("blob", "raw"))).into(img3);
                }
            } else {
                img3.setVisibility(View.GONE);
            }
            if (data.get((int)position).containsKey("img4")) {
                if (data.get((int)position).get("img4").equals("")) {
                    img4.setVisibility(View.GONE);
                } else {
                    img4.setVisibility(View.VISIBLE);
                    Glide.with(getApplicationContext()).load(Uri.parse(data.get((int)position).get("img4").toString().replace("blob", "raw"))).into(img4);
                }
            } else {
                img4.setVisibility(View.GONE);
            }
            linear1.setOnClickListener(view -> {
                if (data.get((int)position).containsKey("link")) {
                    if (!data.get((int)position).get("link").equals("")) {
                        newName = data.get((int)position).get("name").toString().concat(" ".concat(data.get((int)position).get("version").toString()));
                        new DownloadTask().execute(data.get((int)position).get("link").toString().replace("blob", "raw"));
                    } else {
                        Toast.makeText(HomeActivity.this, "Unable to download!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(HomeActivity.this, "Unable to download!", Toast.LENGTH_SHORT).show();
                }
            });
            return _view;
        }
    }

    public void install(final String apk) {
        String PATH = Environment.getExternalStorageDirectory() + apk;
        java.io.File file = new java.io.File(PATH);
        if (file.exists()) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uriFromFile(getApplicationContext(), new java.io.File(PATH)), "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                getApplicationContext().startActivity(intent);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
                Log.e("TAG", "Error in opening the file!");
            }
        } else {
            Toast.makeText(getApplicationContext(),"installing",Toast.LENGTH_LONG).show();
        }
    }
    Uri uriFromFile(Context context, java.io.File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return androidx.core.content.FileProvider.getUriForFile(context,context.getApplicationContext().getPackageName() + ".provider", file);
        } else {
            return Uri.fromFile(file);
        }
    }

    public void _inject() {
    }
    private class DownloadTask extends AsyncTask<String, Integer, String> {
        KProgressHUD hud;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            hud = new KProgressHUD(HomeActivity.this).setStyle(KProgressHUD.Style.ANNULAR_DETERMINATE).setLabel("Please Wait...")
                    .setMaxProgress(100).setCancellable(false);
            hud.show();

        }
        @Override
        protected String doInBackground(String... address) {
            try {
                filename= URLUtil.guessFileName(address[0], null, null);
                int resCode = -1;
                java.io.InputStream in = null;
                java.net.URL url = new java.net.URL(address[0]);
                java.net.URLConnection urlConn = url.openConnection();
                if (!(urlConn instanceof java.net.HttpURLConnection)) {
                    throw new java.io.IOException("URL is not an Http URL");
                }
                java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn;
                httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true);
                httpConn.setRequestMethod("GET");
                httpConn.connect();
                resCode = httpConn.getResponseCode();
                if (resCode == java.net.HttpURLConnection.HTTP_OK) {
                    in = httpConn.getInputStream();
                    size = httpConn.getContentLength();

                } else {
                    result = "There was an error";
                }
                /**/
                if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/DataVault/"))) {
                    FileUtil.createFolderInDirectory(FileUtil.getExternalStorageDir().concat("/DataVault/"));
                }
                if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/DataVault/files/"))) {
                    FileUtil.createFolderInDirectory(FileUtil.getExternalStorageDir().concat("/DataVault/files/"));
                }
                if (!FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/DataVault/cache/"))) {
                    FileUtil.createFolderInDirectory(FileUtil.getExternalStorageDir().concat("/DataVault/cache/"));
                }
                path = FileUtil.getExternalStorageDir().concat("/DataVault/files/".concat(filename));
                path1 = FileUtil.getExternalStorageDir().concat("/DataVault/files/");
                java.io.File file = new java.io.File(path);

                java.io.OutputStream output = new java.io.FileOutputStream(file);
                try {
                    int bytesRead;
                    sumCount = 0;
                    byte[] buffer = new byte[1024];
                    while ((bytesRead = in.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                        sumCount += bytesRead;
                        if (size > 0) {
                            publishProgress((int)Math.round(sumCount*100 / size));
                        }
                    }
                } finally {
                    output.close();
                }
                result ="";
                in.close();
            } catch (java.net.MalformedURLException e) {
                result = e.getMessage();
            } catch (java.io.IOException e) {
                result = e.getMessage();
            } catch (Exception e) {
                result = e.toString();
            }
            return result;

        }
        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            hud.setProgress(values[values.length - 1]);
            hud.setDetailsLabel(String.valueOf((long)(values[values.length - 1])).concat(" %"));
        }
        @Override
        protected void onPostExecute(String s){
            try {
                cv = new AlertDialog.Builder(HomeActivity.this).create();
                LayoutInflater cvLI = getLayoutInflater();
                View cvCV = (View) cvLI.inflate(R.layout.toast, null);
                cv.setView(cvCV);
                cv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                final TextView descriptions = (TextView) cvCV.findViewById(R.id.textview2);
                final TextView open = (TextView) cvCV.findViewById(R.id.textview3);
                FileUtil.renameFile(HomeActivity.this, FileUtil.getExternalStorageDir().concat("/DataVault/files/"), filename, newName.concat(".apk"));
                open.setText("I N S T A L L");
                descriptions.setText(path1.concat(newName.concat(".apk")));
                open.setOnClickListener(view -> {
                    install("/DataVault/files/".concat(newName.concat(".apk")));
                    cv.dismiss();
                });
                cv.setCancelable(true);
                cv.show();
            } catch (Exception error) {
                Toast.makeText(HomeActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void refresh(final String data_key) {
        swipeRefreshLayout.setRefreshing(true);
        internet.startRequestNetwork(RequestNetworkController.GET, data_key, "", _internet_request_listener);
    }

//    public void showDownload(View view) {
//        Intent i = new Intent();
//        //try more options to show downloading , retrieving and complete
//        i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
//        startActivity(i);
//    }
    public void _Transition(final View _view, final double _duration) {
        LinearLayout ViewGroup = (LinearLayout) _view;
        android.transition.AutoTransition autoTransition = new android.transition.AutoTransition();
        autoTransition.setDuration((long)_duration);
        android.transition.TransitionManager.beginDelayedTransition(ViewGroup, autoTransition);
    }
    public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
        if (_ripple) {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(Color.parseColor(_color));
            gd.setCornerRadius((int)_radius);
            gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
            _view.setElevation((int)_shadow);
            android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
            android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
            _view.setClickable(true);
            _view.setBackground(ripdrb);
        }
        else {
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(Color.parseColor(_color));
            gd.setCornerRadius((int)_radius);
            gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
            _view.setBackground(gd);
            _view.setElevation((int)_shadow);
        }
        if (_clickAnim) {
            _view.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()){
                        case MotionEvent.ACTION_DOWN:{
                            ObjectAnimator scaleX = new ObjectAnimator();
                            scaleX.setTarget(_view);
                            scaleX.setPropertyName("scaleX");
                            scaleX.setFloatValues(0.9f);
                            scaleX.setDuration((int)_animDuration);
                            scaleX.start();

                            ObjectAnimator scaleY = new ObjectAnimator();
                            scaleY.setTarget(_view);
                            scaleY.setPropertyName("scaleY");
                            scaleY.setFloatValues(0.9f);
                            scaleY.setDuration((int)_animDuration);
                            scaleY.start();
                            break;
                        }
                        case MotionEvent.ACTION_UP:{

                            ObjectAnimator scaleX = new ObjectAnimator();
                            scaleX.setTarget(_view);
                            scaleX.setPropertyName("scaleX");
                            scaleX.setFloatValues((float)1);
                            scaleX.setDuration((int)_animDuration);
                            scaleX.start();

                            ObjectAnimator scaleY = new ObjectAnimator();
                            scaleY.setTarget(_view);
                            scaleY.setPropertyName("scaleY");
                            scaleY.setFloatValues((float)1);
                            scaleY.setDuration((int)_animDuration);
                            scaleY.start();

                            break;
                        }
                    }
                    return false;
                }
            });
        }
    }
    public void _OnCreate() {
        slot1.setOnClickListener(v -> {
            data = data1;
            refresh(data);
            _slot1();
        });
        slot2.setOnClickListener(v -> {
            data = data2;
            refresh(data);
            _slot2();
        });
        slot3.setOnClickListener(v -> {
            intent.setClass(getApplicationContext(), DownloadActivity.class);
            startActivity(intent);
        });
    }
    public void light_dark(final View _view) {
        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            SketchUi.setColor(0xFF2A2B2F);
            SketchUi.setCornerRadius(d*300);
            SketchUi.setStroke(d*3,0xFF2A2B2F);
            _view.setBackground(SketchUi);
        }
    }
    public void dark(final View _view){
        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            SketchUi.setColor(0xFF202226);
            SketchUi.setCornerRadius(d*300);
            SketchUi.setStroke(d*3,0xFF2A2B2F);
            _view.setBackground(SketchUi);
        }
    }
    public void _slot1() {
        light_dark(slot1);
        dark(slot2);
        dark(slot3);
    }
    public void _slot2() {
        dark(slot1);
        light_dark(slot2);
        dark(slot3);
    }
    public void _slot3() {
        dark(slot1);
        dark(slot2);
        light_dark(slot3);
    }
    @Deprecated
    public void showMessage(String _s) {
        Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
    }
    @Deprecated
    public int getLocationX(View _v) {
        int _location[] = new int[2];
        _v.getLocationInWindow(_location);
        return _location[0];
    }
    @Deprecated
    public int getLocationY(View _v) {
        int _location[] = new int[2];
        _v.getLocationInWindow(_location);
        return _location[1];
    }
    @Deprecated
    public int getRandom(int _min, int _max) {
        Random random = new Random();
        return random.nextInt(_max - _min + 1) + _min;
    }
    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
        ArrayList<Double> _result = new ArrayList<Double>();
        SparseBooleanArray _arr = _list.getCheckedItemPositions();
        for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
            if (_arr.valueAt(_iIdx))
                _result.add((double)_arr.keyAt(_iIdx));
        }
        return _result;
    }
    @Deprecated
    public float getDip(int _input) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
    }
    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }
    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}