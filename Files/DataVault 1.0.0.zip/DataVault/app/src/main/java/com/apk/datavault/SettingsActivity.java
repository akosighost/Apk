package com.apk.datavault;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.FirebaseApp;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class SettingsActivity extends AppCompatActivity {

    private ListView listView;
    private ImageView back;

    private Intent i = new Intent();

    private String app_version;
    private String cache;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        initialize(savedInstanceState);
        FirebaseApp.initializeApp(this);
        initialize();
    }

    private void initialize(Bundle savedInstanceState) {
        listView = findViewById(R.id.list_item);
        back = findViewById(R.id.back);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // This method will be called when an item in the home_list is clicked
                String selectedItem = (String) parent.getItemAtPosition(position);
                if (selectedItem.equals("Offline file data")) {
                    i.setClass(getApplicationContext(), DownloadActivity.class);
                    startActivity(i);
                }
            }
        });
        back.setOnClickListener(view -> {
            if (DataUtil.isConnected(getApplicationContext())) {
                finish();
            } else if (DataUtil.isConnected(getApplicationContext())) {
                finishAffinity();
            }
        });
    }

    private void initialize() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.dark));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.dark));
        updateCacheSizeText();
        try {
            android.content.pm.PackageManager pm = getApplicationContext().getPackageManager();
            android.content.pm.PackageInfo pinfo = pm.getPackageInfo(getApplicationContext().getPackageName().toString(), 0);
            String your_version = pinfo.versionName;
            app_version = your_version;
        } catch (android.content.pm.PackageManager.NameNotFoundException e) { e.printStackTrace(); }
        List<String> item1 = new ArrayList<>(); // mainText
        item1.add("Directory"); // 1
        item1.add("Cache"); // 2
        item1.add("Offline file data"); // 3
        item1.add("About"); // 4
        item1.add("Developer"); // 5
        List<String> item2 = new ArrayList<>(); // subText
        item2.add(FileUtil.getExternalStorageDir().concat("/DataVault/files/")); // 1
        item2.add("Clear Caches"); // 2
        item2.add(""); // 3
        item2.add("Current Version : ".concat(app_version)); // 4
        item2.add("Jhayr Natividad"); // 5
        SettingsAdapter adapter = new SettingsAdapter(this, item1, item2);
        listView.setAdapter(adapter);
        listView.setHorizontalScrollBarEnabled(false);
        listView.setVerticalScrollBarEnabled(false);
        listView.setDivider(null);
        listView.setDividerHeight(0);
        OverScrollDecoratorHelper.setUpOverScroll(listView);
    }

//    public class NotificationHelper {
//
//        private static final String CHANNEL_ID = "your_channel_id"; // You can change this ID if needed.
//        private static final String CHANNEL_NAME = "Your Channel Name"; // Change this to the desired channel name.
//        private static final String CHANNEL_DESCRIPTION = "Your Channel Description"; // Change this to the desired channel description.
//
//        private Context context;
//        private NotificationManager notificationManager;
//
//        public NotificationHelper(Context context) {
//            this.context = context;
//            createNotificationChannel();
//        }
//
//        private void createNotificationChannel() {
//            // Create the notification channel on devices running Android Oreo (API 26) and above.
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                NotificationChannel channel = new NotificationChannel(
//                        CHANNEL_ID,
//                        CHANNEL_NAME,
//                        NotificationManager.IMPORTANCE_DEFAULT
//                );
//                channel.setDescription(CHANNEL_DESCRIPTION);
//
//                // Register the channel with the system
//                notificationManager = context.getSystemService(NotificationManager.class);
//                if (notificationManager != null) {
//                    notificationManager.createNotificationChannel(channel);
//                }
//            }
//        }
//
//        public void showNotification(String title, String message) {
//            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
//                    .setSmallIcon(R.drawable.notifications) // Replace with your notification icon
//                    .setContentTitle(title)
//                    .setContentText(message)
//                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);
//
//            // Show the notification
//            notificationManager.notify(/*notificationId*/0, builder.build());
//        }
//    }

    // Method for the "Clear Cache" button click
    public void onClearCacheButtonClick(View view) {
        clearCache(this);
        Toast.makeText(this, "Cache cleared.", Toast.LENGTH_SHORT).show();

        // Update the cache size TextView after clearing the cache
        updateCacheSizeText();
    }

    // Method to clear the cache directory
    private void clearCache(Context context) {
        try {
            File cacheDir = context.getCacheDir();
            if (cacheDir != null && cacheDir.isDirectory()) {
                File[] cacheFiles = cacheDir.listFiles();
                if (cacheFiles != null) {
                    for (File file : cacheFiles) {
                        file.delete();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to update the cache size TextView
    private void updateCacheSizeText() {
        long cacheSize = getCacheSize(this);
        String formattedCacheSize = Formatter.formatFileSize(this, cacheSize);
//        tvCacheSize.setText("Cache Size: " + formattedCacheSize);
        cache = formattedCacheSize;
    }

    // Method to calculate the cache size in bytes
    private long getCacheSize(Context context) {
        long size = 0;
        try {
            File cacheDir = context.getCacheDir();
            if (cacheDir != null && cacheDir.isDirectory()) {
                File[] cacheFiles = cacheDir.listFiles();
                if (cacheFiles != null) {
                    for (File file : cacheFiles) {
                        size += file.length();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return size;
    }


    @Override
    public void onBackPressed() {
        if (DataUtil.isConnected(getApplicationContext())) {
            finish();
        } else if (DataUtil.isConnected(getApplicationContext())) {
            finishAffinity();
        }
    }

    @Deprecated
    public void showMessage(String _s) {
        Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View _v) {
        int[] _location = new int[2];
        _v.getLocationInWindow(_location);
        return _location[0];
    }

    @Deprecated
    public int getLocationY(View _v) {
        int[] _location = new int[2];
        _v.getLocationInWindow(_location);
        return _location[1];
    }

    @Deprecated
    public int getRandom(int _min, int _max) {
        Random random = new Random();
        return random.nextInt(_max - _min + 1) + _min;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
        ArrayList<Double> _result = new ArrayList<Double>();
        SparseBooleanArray _arr = _list.getCheckedItemPositions();
        for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
            if (_arr.valueAt(_iIdx))
                _result.add((double) _arr.keyAt(_iIdx));
        }
        return _result;
    }

    @Deprecated
    public float getDip(int _input) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}