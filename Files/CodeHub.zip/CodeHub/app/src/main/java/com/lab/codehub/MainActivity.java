package com.lab.codehub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private Intent i = new Intent();
    private Timer _timer = new Timer();
    private TimerTask t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Window w = this.getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(0xFF202226);
        w.setNavigationBarColor(0xFF202226);
    }

    @Override
    public void onStart() {
        super.onStart();
        t = new TimerTask() {
            @Override
            public void run() {
                i.setClass(getApplicationContext(), HomeActivity.class);
                startActivity(i);
            }
        };
        _timer.schedule(t, (int)3000);
    }
}