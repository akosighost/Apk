package com.lab.codehub;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;

public class HomeActivity extends AppCompatActivity {

    private LinearLayout add_holder;
    private ListView listview1;
    private SwipeRefreshLayout swipe;

    private Intent i = new Intent();
    private RequestNetwork net;
    private RequestNetwork.RequestListener _net_request_listener;

    private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initialize(savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle savedInstanceState) {
        net = new RequestNetwork(this);
        add_holder = findViewById(R.id.add_holder);
        listview1 = findViewById(R.id.listview1);
        swipe = findViewById(R.id.swipe);

        add_holder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.setClass(getApplicationContext(), AddCodesActivity.class);
                startActivity(i);
            }
        });

        _net_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;
                try {
                    swipe.setRefreshing(false);
                    listmap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
                    listview1.setAdapter(new Listview1Adapter(listmap));
                    ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                }
                catch (Exception e) {
                    e.printStackTrace();
                    swipe.setRefreshing(false);
                }
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;
            }
        };
    }

    @Override
    public void onBackPressed() {
        final AlertDialog option = new AlertDialog.Builder(HomeActivity.this).create();
        LayoutInflater Inflater = getLayoutInflater();
        View view = (View) Inflater.inflate(R.layout.exit_popup, null);
        option.setView(view);
        option.requestWindowFeature(Window.FEATURE_NO_TITLE);
        option.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

        Button button1 = (Button)view.findViewById(R.id.button1);
        Button button2 = (Button)view.findViewById(R.id.button2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                option.dismiss();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
            }
        });
        option.show();
    }

    private void initializeLogic() {
        Window w = this.getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(0xFF202226);
        w.setNavigationBarColor(0xFF202226);
        net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/CodeHud-Data/", "", _net_request_listener);
        listview1.setHorizontalScrollBarEnabled(false);
        listview1.setVerticalScrollBarEnabled(false);
        listview1.setDivider(null);
        listview1.setDividerHeight(0);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/CodeHud-Data/", "", _net_request_listener);
            }
        });
    }

    public class Listview1Adapter extends BaseAdapter {

        ArrayList<HashMap<String, Object>> _data;

        public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public int getCount() {
            return _data.size();
        }

        @Override
        public HashMap<String, Object> getItem(int _index) {
            return _data.get(_index);
        }

        @Override
        public long getItemId(int _index) {
            return _index;
        }

        @Override
        public View getView(final int _position, View _v, ViewGroup _container) {
            LayoutInflater _inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View _view = _v;
            if (!_data.get((int) _position).get("header").toString().isEmpty()) {
                if (_data.get((int) _position).get("header").equals("true")) {
                    _view = _inflater.inflate(R.layout.header_list, null);
                } else {
                    _view = _inflater.inflate(R.layout.home_list, null);
                }
            }

            final TextView textview1 = _view.findViewById(R.id.textview1);
            final TextView textview2 = _view.findViewById(R.id.textview2);
            final TextView textview3 = _view.findViewById(R.id.textview3);
            final TextView textview4 = _view.findViewById(R.id.textview4);
            final LinearLayout linear2 = _view.findViewById(R.id.linear2);
            final LinearLayout linear5 = _view.findViewById(R.id.linear5);
            final ImageView imageview1 = _view.findViewById(R.id.imageview1);

            {
                android.graphics.drawable.GradientDrawable NatiUi = new android.graphics.drawable.GradientDrawable();
                int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                NatiUi.setColor(0xFF202226);
                NatiUi.setStroke(d*1,0xFF2A2B2F);
                linear2.setElevation(d*5);
                android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF616161}), NatiUi, null);
                linear2.setBackground(SketchUiRD);
                linear2.setClickable(true);
            }
            {
                android.graphics.drawable.GradientDrawable NatiUi = new android.graphics.drawable.GradientDrawable();
                int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                NatiUi.setColor(0xFF202226);
                NatiUi.setStroke(d*1,0xFF2A2B2F);
                textview4.setElevation(d*5);
                android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF616161}), NatiUi, null);
                textview4.setBackground(SketchUiRD);
                textview4.setClickable(true);
            }

            if (_data.get((int)_position).containsKey("title")) {
                textview1.setText(_data.get((int)_position).get("title").toString());
            }
            else {
                textview1.setVisibility(View.GONE);
            }
            if (_data.get((int)_position).containsKey("sub_tittle")) {
                textview2.setText(_data.get((int)_position).get("sub_tittle").toString());
            }
            else {
                textview2.setVisibility(View.GONE);
            }
            if (_data.get((int)_position).containsKey("description")) {
                textview3.setText(_data.get((int)_position).get("description").toString());
            }
            else {
                textview4.setVisibility(View.GONE);
            }
            if (_data.get((int)_position).containsKey("text_button")) {
                textview4.setText(_data.get((int)_position).get("text_button").toString());
            }
            else {
                textview4.setVisibility(View.GONE);
            }

            if (_data.get((int)_position).containsKey("button")) {
                if (_data.get((int)_position).get("button").equals("false")) {
                    linear5.setVisibility(View.GONE);
                }
                else {
                    if (_data.get((int)_position).get("button").equals("true")) {
                        linear5.setVisibility(View.VISIBLE);
                    }
                }
            }
            else {
                linear5.setVisibility(View.GONE);
            }
            if (_data.get((int)_position).containsKey("image")) {
                if (_data.get((int)_position).get("image").equals("false")) {
                    imageview1.setVisibility(View.GONE);
                }
                else {
                    if (_data.get((int)_position).get("image").equals("true")) {
                        imageview1.setVisibility(View.VISIBLE);
                    }
                }
            }
            else {
                imageview1.setVisibility(View.GONE);
            }

            linear2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (_data.get((int)_position).containsKey("data")) {
                        i.setClass(getApplicationContext(), CodesActivity.class);
                        i.putExtra("data", listmap.get((int)_position).get("data").toString());
                        startActivity(i);
                    }
                    else {

                    }
                }
            });
            return _view;
        }
    }
}