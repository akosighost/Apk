package com.lab.codehub;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class CodesActivity extends AppCompatActivity {

    private ListView listview1;
    private EditText edittext1;
    private SwipeRefreshLayout swipe;
    private TextView textview1;
    private ImageView imageview1;
    private ImageView imageview2;
    private ImageView imageview3;
    private LinearLayout linear3;
    private LinearLayout edittext1_holder;

    private Intent i = new Intent();
    private RequestNetwork net;
    private RequestNetwork.RequestListener _net_request_listener;
    private SharedPreferences search;

    private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();

    private String save = "";
    private String value = "";
    private double number = 0;
    private double length = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_codes);
        initialize(savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle savedInstanceState) {
        search = getSharedPreferences("search", Activity.MODE_PRIVATE);
        net = new RequestNetwork(this);
        listview1 = findViewById(R.id.listview1);
        edittext1 = findViewById(R.id.edittext1);
        swipe = findViewById(R.id.swipe);
        textview1 = findViewById(R.id.textview1);
        imageview1 = findViewById(R.id.imageview1);
        imageview2 = findViewById(R.id.imageview2);
        imageview3 = findViewById(R.id.imageview3);
        linear3 = findViewById(R.id.linear3);
        edittext1_holder = findViewById(R.id.edittext1_holder);

        imageview1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        imageview2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText("");
            }
        });
        imageview3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog option = new AlertDialog.Builder(CodesActivity.this).create();
                LayoutInflater Inflater = getLayoutInflater();
                View view = (View) Inflater.inflate(R.layout.search_popup, null);
                option.setView(view);
                option.requestWindowFeature(Window.FEATURE_NO_TITLE);
                option.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

                RadioButton radiobutton1 = (RadioButton)view.findViewById(R.id.radiobutton1);
                RadioButton radiobutton2 = (RadioButton)view.findViewById(R.id.radiobutton2);
                RadioButton radiobutton3 = (RadioButton)view.findViewById(R.id.radiobutton3);
                Button button1 = (Button)view.findViewById(R.id.button1);
                Button button2 = (Button)view.findViewById(R.id.button2);

                if (search.getString("search", "").equals("")) {
                    radiobutton1.setChecked(true);
                    radiobutton2.setChecked(false);
                    radiobutton3.setChecked(false);
                }
                else {
                    if (search.getString("search", "").equals("type")) {
                        radiobutton1.setChecked(true);
                        radiobutton2.setChecked(false);
                        radiobutton3.setChecked(false);
                    }
                    if (search.getString("search", "").equals("description")) {
                        radiobutton1.setChecked(false);
                        radiobutton2.setChecked(true);
                        radiobutton3.setChecked(false);
                    }
                    if (search.getString("search", "").equals("code")) {
                        radiobutton1.setChecked(false);
                        radiobutton2.setChecked(false);
                        radiobutton3.setChecked(true);
                    }
                }

                button1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        option.dismiss();
                    }
                });
                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (radiobutton1.isChecked()) {
                            search.edit().putString("search", "type").commit();
                        }
                        if (radiobutton2.isChecked()) {
                            search.edit().putString("search", "description").commit();
                        }
                        if (radiobutton3.isChecked()) {
                            search.edit().putString("search", "code").commit();
                        }
                        option.dismiss();
                    }
                });
                option.show();
            }
        });

        _net_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                final String _tag = _param1;
                final String _response = _param2;
                final HashMap<String, Object> _responseHeaders = _param3;
                try {
                    swipe.setRefreshing(false);
                    listmap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
                    listview1.setAdapter(new Listview1Adapter(listmap));
                    ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                    textview1.setText(String.valueOf((long)(listmap.size())));
                    textview1.setText("Codes (".concat(String.valueOf((long)(listmap.size())).concat(")")));
                    save = new Gson().toJson(listmap);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    swipe.setRefreshing(false);
                }
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                final String _tag = _param1;
                final String _message = _param2;
            }
        };

        edittext1.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
                final String _charSeq = _param1.toString();
                if (edittext1.getText().toString().length() == 0) {
                    Transition(linear3, 300);
                    Transition(edittext1_holder, 300);
                    imageview2.setVisibility(View.GONE);
                    edittext1.setCursorVisible(false);

                }
                else {
                    Transition(linear3, 300);
                    Transition(edittext1_holder, 300);
                    imageview2.setVisibility(View.VISIBLE);
                    edittext1.setCursorVisible(true);
                }

                try {
                    listmap = new Gson().fromJson(save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
                    length = listmap.size();
                    number = length - 1;
                    for (int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
                        if (search.getString("search", "").equals("type")) {
                            value = listmap.get((int)number).get("type").toString();
                        }
                        else {
                            if (search.getString("search", "").equals("description")) {
                                value = listmap.get((int)number).get("description").toString();
                            }
                            else {
                                if (search.getString("search", "").equals("code")) {
                                    value = listmap.get((int)number).get("code").toString();
                                }
                                else {
                                    value = listmap.get((int)number).get("type").toString();
                                }
                            }
                        }

                        if (!(_charSeq.length() > value.length()) && value.toLowerCase().contains(_charSeq.toLowerCase())) {

                        }
                        else {
                            listmap.remove((int)(number));
                            listview1.setAdapter(new Listview1Adapter(listmap));
                            ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                        }
                        number --;
                    }
                    listview1.setAdapter(new Listview1Adapter(listmap));
                    ((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
                }
                catch (Exception e) {

                }
            }

            @Override
            public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {

            }

            @Override
            public void afterTextChanged(Editable _param1) {

            }
        });
    }

    private void initializeLogic() {
        Window w = this.getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(0xFF202226);
        w.setNavigationBarColor(0xFF202226);
        if (getIntent().hasExtra("data")) {
            net.startRequestNetwork(RequestNetworkController.GET, getIntent().getStringExtra("data"), "", _net_request_listener);
        }
        else {

        }
        imageview2.setVisibility(View.GONE);
        listview1.setHorizontalScrollBarEnabled(false);
        listview1.setVerticalScrollBarEnabled(false);
        listview1.setDivider(null);
        listview1.setDividerHeight(0);
        OverScrollDecoratorHelper.setUpOverScroll(listview1);
        edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 20) {}});
        {
            android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
            int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            SketchUi.setColor(0xFF202226);SketchUi.setStroke(d*1,0xFF2A2B2F);
            edittext1.setElevation(d*5);
            edittext1.setBackground(SketchUi);
        }
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (getIntent().hasExtra("data")) {
                    net.startRequestNetwork(RequestNetworkController.GET, getIntent().getStringExtra("data"), "", _net_request_listener);
                }
                else {

                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    public class Listview1Adapter extends BaseAdapter {

        ArrayList<HashMap<String, Object>> _data;

        public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public int getCount() {
            return _data.size();
        }

        @Override
        public HashMap<String, Object> getItem(int _index) {
            return _data.get(_index);
        }

        @Override
        public long getItemId(int _index) {
            return _index;
        }

        @Override
        public View getView(final int _position, View _v, ViewGroup _container) {
            LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View _view = _v;
            if (_view == null) {
                _view = _inflater.inflate(R.layout.code_list, null);
            }

            final TextView textview1 = _view.findViewById(R.id.textview1);
            final TextView textview2 = _view.findViewById(R.id.textview2);
            final TextView textview3 = _view.findViewById(R.id.textview3);
            final LinearLayout linear1 = _view.findViewById(R.id.linear1);

            textview1.setText(String.valueOf((long)(_position + 1)));
            textview2.setText(_data.get((int)_position).get("type").toString());
            textview3.setText(_data.get((int)_position).get("description").toString());

            linear1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    i.setClass(getApplicationContext(), ViewCodesActivity.class);
                    if (listmap.get((int)0).containsKey("type")) {
                        i.putExtra("type", _data.get((int)_position).get("type").toString());
                    }
                    if (listmap.get((int)0).containsKey("description")) {
                        i.putExtra("description", _data.get((int)_position).get("description").toString());
                    }
                    if (listmap.get((int)0).containsKey("code")) {
                        i.putExtra("code", _data.get((int)_position).get("code").toString());
                    }
                    startActivity(i);
                }
            });
            return _view;
        }
    }

    public void Transition(final View _view, final double _duration) {
        LinearLayout ViewGroup = (LinearLayout) _view;

        android.transition.AutoTransition autoTransition = new android.transition.AutoTransition();
        autoTransition.setDuration((long)_duration);
        android.transition.TransitionManager.beginDelayedTransition(ViewGroup, autoTransition);
    }
}