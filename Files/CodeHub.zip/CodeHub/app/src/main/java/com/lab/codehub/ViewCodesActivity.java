package com.lab.codehub;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.CharacterStyle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.shashank.sony.fancytoastlib.FancyToast;

import java.util.Timer;
import java.util.TimerTask;

import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class ViewCodesActivity extends AppCompatActivity {

    private ImageView imageview1;
    private ImageView imageview2;
    private ImageView imageview3;
    private ImageView imageview4;
    private ImageView imageview5;
    private TextView textview1;
    private TextView textview2;
    private ScrollView scroll1;
    private HorizontalScrollView scroll2;

    private double number = 0;

    private SharedPreferences save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_codes);
        initialize(savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle savedInstanceState) {
        save = getSharedPreferences("value", Activity.MODE_PRIVATE);
        imageview1 = findViewById(R.id.imageview1);
        imageview2 = findViewById(R.id.imageview2);
        imageview3 = findViewById(R.id.imageview3);
        imageview4 = findViewById(R.id.imageview4);
        imageview5 = findViewById(R.id.imageview5);
        textview1 = findViewById(R.id.textview1);
        textview2 = findViewById(R.id.textview2);
        scroll1 = findViewById(R.id.scroll1);
        scroll2 = findViewById(R.id.scroll2);

        imageview1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        imageview2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ClipboardManager)getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview2.getText().toString()));
                FancyToast.makeText(ViewCodesActivity.this,"Copied!",FancyToast.LENGTH_LONG,FancyToast.SUCCESS,false).show();
            }
        });
        imageview3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(number == 30)) {
                    number ++;
                    textview2.setTextSize((int)number);
                    save.edit().putString("value", String.valueOf((long)(number))).commit();
                }
            }
        });
        imageview4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(number == 11)) {
                    number --;
                    textview2.setTextSize((int)number);
                    save.edit().putString("value", String.valueOf((long)(number))).commit();
                }
            }
        });
        imageview5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(android.content.Intent.EXTRA_TEXT, textview2.getText().toString());
                startActivity(Intent.createChooser(i, "Please choose an action"));
            }
        });
    }

    private void initializeLogic() {
        Window w = this.getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(0xFF202226);
        w.setNavigationBarColor(0xFF202226);

        if (save.contains("value")) {
            number = Double.parseDouble(save.getString("value", ""));
            textview2.setTextSize((int)number);
        }
        else {
            number = 11;
            textview2.setTextSize((int)number);
        }

        if (getIntent().hasExtra("type") && getIntent().hasExtra("description")) {
            textview1.setEllipsize(TextUtils.TruncateAt.MARQUEE);
            textview1.setText(getIntent().getStringExtra("type").concat(" | ").concat(getIntent().getStringExtra("description")));
            textview1.setSelected(true);
            textview1.setSingleLine(true);
        }
        else {
            textview1.setText("Loading... | Loading...");
        }

        if (getIntent().hasExtra("code")) {
            textview2.setText(getIntent().getStringExtra("code"));
        }
        highlighter(textview2);
        scroll1.setHorizontalScrollBarEnabled(false);

        scroll1.setHorizontalScrollBarEnabled(false);
        scroll1.setVerticalScrollBarEnabled(false);
        scroll2.setHorizontalScrollBarEnabled(false);
        scroll2.setVerticalScrollBarEnabled(false);
        OverScrollDecoratorHelper.setUpOverScroll(scroll1);
        OverScrollDecoratorHelper.setUpOverScroll(scroll2);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    public void highlighter(final TextView _view) {
        final String secondaryColor = "#678cb1";
        final String primaryColor = "#86b55a";
        final String numbersColor = "#f6c921";
        final String quotesColor = "#ff1744";
        final String commentsColor = "#9e9e9e";
        final String charColor = "#ff5722";

        final TextView regex1 = new TextView(this);
        final TextView regex2 = new TextView(this);
        final TextView regex3 = new TextView(this);
        final TextView regex4 = new TextView(this);
        final TextView regex5 = new TextView(this);
        final TextView regex6 = new TextView(this);
        final TextView regex7 = new TextView(this);
        final TextView regex8 = new TextView(this);
        final TextView regex9 = new TextView(this);
        final TextView regex10 = new TextView(this);
        final TextView regex11 = new TextView(this);

        regex1.setText("\\b(out|print|println|valueOf|toString|concat|equals|for|while|switch|getText");

        regex2.setText("|println|printf|print|out|parseInt|round|sqrt|charAt|compareTo|compareToIgnoreCase|concat|contains|contentEquals|equals|length|toLowerCase|trim|toUpperCase|toString|valueOf|substring|startsWith|split|replace|replaceAll|lastIndexOf|size)\\b");

        regex3.setText("\\b(public|private|protected|void|switch|case|class|import|package|extends|Activity|TextView|EditText|LinearLayout|CharSequence|String|int|onCreate|ArrayList|float|if|else|static|Intent|Button|SharedPreferences");

        regex4.setText("|abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|instanceof|interface|long|native|new|package|private|protected|");

        regex5.setText("public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|void|volatile|while|true|false|null)\\b");

        regex6.setText("\\b([0-9]+)\\b");

        regex7.setText("(\\w+)(\\()+");

        regex8.setText("\\@\\s*(\\w+)");

        regex9.setText("\"(.*?)\"|'(.*?)'");

        regex10.setText("/\\*(?:.|[\\n\\r])*?\\*/|//.*");

        regex11.setText("\\b(Uzuakoli|Amoji|Bright|Ndudirim|Ezinwanne|Lightworker|Isuochi|Abia|Ngodo)\\b");

        _view.addTextChangedListener(new TextWatcher() {
            final ColorScheme keywords1 = new ColorScheme(java.util.regex.Pattern.compile(regex1.getText().toString().concat(regex2.getText().toString())), Color.parseColor(secondaryColor));
            final ColorScheme keywords2 = new ColorScheme(java.util.regex.Pattern.compile(regex3.getText().toString().concat(regex4.getText().toString().concat(regex5.getText().toString()))), Color.parseColor(primaryColor));
            final ColorScheme keywords3 = new ColorScheme(java.util.regex.Pattern.compile(regex6.getText().toString()), Color.parseColor(numbersColor));
            final ColorScheme keywords4 = new ColorScheme(java.util.regex.Pattern.compile(regex7.getText().toString()), Color.parseColor(secondaryColor));
            final ColorScheme keywords5 = new ColorScheme(java.util.regex.Pattern.compile(regex9.getText().toString()), Color.parseColor(quotesColor));
            final ColorScheme keywords6 = new ColorScheme(java.util.regex.Pattern.compile(regex10.getText().toString()), Color.parseColor(commentsColor));
            final ColorScheme keywords7 = new ColorScheme(java.util.regex.Pattern.compile(regex8.getText().toString()), Color.parseColor(numbersColor));
            ColorScheme keywords8 = new ColorScheme(java.util.regex.Pattern.compile(regex11.getText().toString()), Color.parseColor(charColor));

            final ColorScheme[] schemes = { keywords1, keywords2, keywords3, keywords4, keywords5, keywords6, keywords7, keywords8 };
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                removeSpans(s, android.text.style.ForegroundColorSpan.class);
                for (ColorScheme scheme : schemes) {
                    for (java.util.regex.Matcher m = scheme.pattern.matcher(s); m.find();) {
                        if (scheme == keywords4) {
                            s.setSpan(new android.text.style.ForegroundColorSpan(scheme.color), m.start(), m.end()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                        else {
                            s.setSpan(new android.text.style.ForegroundColorSpan(scheme.color), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                }

            }
            void removeSpans(Editable e, Class type) {
                android.text.style.CharacterStyle[] spans = (CharacterStyle[]) e.getSpans(0, e.length(), type);
                for (android.text.style.CharacterStyle span : spans) {
                    e.removeSpan(span);
                }
            }
            class ColorScheme {
                final java.util.regex.Pattern pattern;
                final int color;
                ColorScheme(java.util.regex.Pattern pattern, int color) {
                    this.pattern = pattern;
                    this.color = color;
                }
            }
        });
    }
}